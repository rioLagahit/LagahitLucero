<?php require_once("shared/cookies.php"); ?>
<?php require_once("shared/functions.php"); ?>
<?php require_once("shared/header.php"); ?>

<div class="outerBox noLowerBox">
	<div class="titleBox">Error</div>

	<div class="innerBox">
		<p class="center">
			You don't have permission to acess this page. 
		</p>
	</div>
</div>


<?php require_once("shared/footer.php"); ?>
<?php require_once("shared/cookies.php"); ?>
<?php require_once("shared/functions.php"); ?>
<?php require_once("shared/header.php"); ?>

<div class="outerBox noLowerBox">
	<div class="titleBox">Error</div>

	<div class="innerBox">
		<p class="center">
			The page that you're looking for doesn't exist. 
		</p>
	</div>
</div>


<?php require_once("shared/footer.php"); ?>
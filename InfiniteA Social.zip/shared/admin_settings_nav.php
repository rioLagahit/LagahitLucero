<div class="v_nav">
	<ul>
		<li><a href="settings_create_sections.php">Create Section</a></li>
		<li><a href="settings_create_forums.php">Create Forum</a></li>
		<li><a href="settings_sections.php">Sections Settings</a></li>
		<li><a href="settings_forums.php">Forums Settings</a></li>
		<li><a href="settings_delete.php">Delete</a></li>
		<li><a href="settings_list_admins.php">List of Administrators</a></li>
		<li><a href="settings_list_mods.php">List of Moderators</a></li>
		<li><a href="settings_list_banned.php">List of Banned Users</a></li>
	</ul>
</div>
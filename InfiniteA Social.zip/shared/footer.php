	<!-- end of content -->
	</div>

	<div id="footer">
		
	</div>

	<?php 
		close_connection();
	?>

</body>
</html>
<div id="nav">
	<ul>
		<li><a href="index_.php">Forums</a></li>
		<li><a href="register.php">Join</a></li>
		<li><a href="login.php">Login</a></li>
		<li><a href="search.php">Search</a></li>
	</ul>
</div>
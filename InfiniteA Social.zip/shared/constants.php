<?php

	define("SERVER", "Localhost");
	define("USER", "root");
	define("PASSWORD", "");
	define("MAIN_DATABASE", "social");

?>